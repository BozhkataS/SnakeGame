﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace SnakeGame
{
    public partial class EasyForm : Form
    {
        private List<Point> snake = new List<Point>();
        private Point food;
        private int width = 20;
        private int height = 20;
        private int score = 0;
        private string direction = "right";
        private Random rand = new Random();
        private Image appleImage;
        private Image headUpImage;
        private Image headDownImage;
        private Image headLeftImage;
        private Image headRightImage;
        private Image tailUpImage;
        private Image tailDownImage;
        private Image tailLeftImage;
        private Image tailRightImage;
        private Image bodyUpDownImage;
        private Image bodyLeftRightImage;
        private Image curveUpRightImage;
        private Image curveRightDownImage;
        private Image curveDownLeftImage;
        private Image curveLeftUpImage;
        private int initialInterval = 150;
        private int intervalDecrease = 2;

        public EasyForm()
        {
            InitializeComponent();
            InitializeGame();
        }

        private void InitializeGame()
        {
            this.DoubleBuffered = true;
            snake.Clear();
            snake.Add(new Point(12, 10));
            snake.Add(new Point(11, 10));
            snake.Add(new Point(10, 10));
            direction = "right";
            score = 0;
            GenerateFood();
            timer1.Interval = initialInterval;
            timer1.Start();
            appleImage = Properties.Resources.apple;
            headUpImage = Properties.Resources.HeadUpTransparent;
            headDownImage = Properties.Resources.HeadDownTransparent;
            headLeftImage = Properties.Resources.HeadLeftTransparent;
            headRightImage = Properties.Resources.HeadRightTransparent;
            tailUpImage = Properties.Resources.TailUpTransparent;
            tailDownImage = Properties.Resources.TailDownTransparent;
            tailLeftImage = Properties.Resources.TailLeftTransparent;
            tailRightImage = Properties.Resources.TailRightTransparent;
            bodyUpDownImage = Properties.Resources.BodyUpDown;
            bodyLeftRightImage = Properties.Resources.BodyLeftRight;
            curveUpRightImage = Properties.Resources.CurveUpRight;
            curveRightDownImage = Properties.Resources.CurveDownRight;
            curveDownLeftImage = Properties.Resources.CurveDownLeft;
            curveLeftUpImage = Properties.Resources.CurveUpLeft;
        }

        private void GenerateFood()
        {
            food = new Point(rand.Next(0, this.ClientSize.Width / width), rand.Next(0, this.ClientSize.Height / height));
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            MoveSnake();
            CheckCollision();
            this.Invalidate();
        }

        private void MoveSnake()
        {
            Point head = snake[0];
            Point newHead = head;

            switch (direction)
            {
                case "up":
                    newHead.Y -= 1;
                    break;
                case "down":
                    newHead.Y += 1;
                    break;
                case "left":
                    newHead.X -= 1;
                    break;
                case "right":
                    newHead.X += 1;
                    break;
            }

            if (newHead.X < 0)
            {
                newHead.X = this.ClientSize.Width / width - 1;
            }
            else if (newHead.X >= this.ClientSize.Width / width)
            {
                newHead.X = 0;
            }

            if (newHead.Y < 0)
            {
                newHead.Y = this.ClientSize.Height / height - 1;
            }
            else if (newHead.Y >= this.ClientSize.Height / height)
            {
                newHead.Y = 0;
            }

            for (int i = 1; i < snake.Count; i++)
            {
                if (snake[i] == newHead)
                {
                    GameOver();
                    return;
                }
            }

            snake.Insert(0, newHead);

            if (newHead == food)
            {
                score++;
                GenerateFood();
                if (timer1.Interval > intervalDecrease)
                {
                    timer1.Interval -= intervalDecrease;
                }
            }
            else
            {
                snake.RemoveAt(snake.Count - 1);
            }
        }

        private void CheckCollision()
        {
            Point head = snake[0];
            if (head == food)
            {
                snake.Add(food);
                GenerateFood();
            }
        }

        private void GameOver()
        {
            timer1.Stop();
            GameOverForm gameOverForm = new GameOverForm(score);
            gameOverForm.Show();
            this.Hide();
        }

        private void EasyForm_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;

            for (int i = 0; i < snake.Count; i++)
            {
                Point p = snake[i];
                if (i == 0)
                {
                    Image headImage = headRightImage;

                    switch (direction)
                    {
                        case "up":
                            headImage = headUpImage;
                            break;
                        case "down":
                            headImage = headDownImage;
                            break;
                        case "left":
                            headImage = headLeftImage;
                            break;
                        case "right":
                            headImage = headRightImage;
                            break;
                    }

                    g.DrawImage(headImage, new Rectangle(p.X * width, p.Y * height, width, height));
                }
                else if (i == snake.Count - 1)
                {
                    Image tailImage = tailRightImage;
                    Point tail = snake[i];
                    Point beforeTail = snake[i - 1];

                    if (beforeTail.X > tail.X)
                    {
                        tailImage = tailRightImage;
                    }
                    else if (beforeTail.X < tail.X)
                    {
                        tailImage = tailLeftImage;
                    }
                    else if (beforeTail.Y > tail.Y)
                    {
                        tailImage = tailDownImage;
                    }
                    else if (beforeTail.Y < tail.Y)
                    {
                        tailImage = tailUpImage;
                    }

                    g.DrawImage(tailImage, new Rectangle(p.X * width, p.Y * height, width, height));
                }
                else
                {
                    Point before = snake[i - 1];
                    Point after = snake[i + 1];
                    Image bodyImage = bodyLeftRightImage;

                    if (before.X == after.X)
                    {
                        bodyImage = bodyUpDownImage;
                    }
                    else if (before.Y == after.Y)
                    {
                        bodyImage = bodyLeftRightImage;
                    }
                    else
                    {
                        if ((before.X < p.X && after.Y < p.Y) || (before.Y < p.Y && after.X < p.X))
                        {
                            bodyImage = curveUpRightImage;
                        }
                        else if ((before.X < p.X && after.Y > p.Y) || (before.Y > p.Y && after.X < p.X))
                        {
                            bodyImage = curveRightDownImage;
                        }
                        else if ((before.X > p.X && after.Y > p.Y) || (before.Y > p.Y && after.X > p.X))
                        {
                            bodyImage = curveDownLeftImage;
                        }
                        else if ((before.X > p.X && after.Y < p.Y) || (before.Y < p.Y && after.X > p.X))
                        {
                            bodyImage = curveLeftUpImage;
                        }
                    }

                    g.DrawImage(bodyImage, new Rectangle(p.X * width, p.Y * height, width, height));
                }
            }
            g.DrawImage(appleImage, new Rectangle(food.X * width, food.Y * height, width, height));
        }


        private void EasyForm_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Up:
                    if (direction != "down") direction = "up";
                    break;
                case Keys.Down:
                    if (direction != "up") direction = "down";
                    break;
                case Keys.Left:
                    if (direction != "right") direction = "left";
                    break;
                case Keys.Right:
                    if (direction != "left") direction = "right";
                    break;
            }
        }

        private void EasyForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
