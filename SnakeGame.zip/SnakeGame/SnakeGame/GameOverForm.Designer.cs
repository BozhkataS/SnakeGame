﻿namespace SnakeGame
{
    partial class GameOverForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Button btnNewGame;
        private System.Windows.Forms.Button btnEasy;
        private System.Windows.Forms.Button btnHard;
        private System.Windows.Forms.Button btnQuit;
        private System.Windows.Forms.Label lblScore;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GameOverForm));
            btnNewGame = new Button();
            lblScore = new Label();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            btnEasy = new Button();
            btnHard = new Button();
            btnQuit = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // lblScore
            // 
            lblScore.AutoSize = true;
            lblScore.BackColor = Color.Transparent;
            lblScore.Font = new Font("Lucida Calligraphy", 18F, FontStyle.Bold);
            lblScore.Location = new Point(347, 87);
            lblScore.Name = "lblScore";
            lblScore.Size = new Size(0, 31);
            lblScore.TabIndex = 1;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Transparent;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(599, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(384, 350);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 2;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Lucida Calligraphy", 20.25F, FontStyle.Bold);
            label1.Location = new Point(382, 38);
            label1.Name = "label1";
            label1.Size = new Size(185, 36);
            label1.TabIndex = 3;
            label1.Text = "YOU DIED";
            // 
            // btnNewGame
            // 
            btnNewGame.BackColor = Color.Transparent;
            btnNewGame.FlatAppearance.BorderSize = 0;
            btnNewGame.FlatAppearance.MouseDownBackColor = Color.Transparent;
            btnNewGame.FlatAppearance.MouseOverBackColor = Color.Transparent;
            btnNewGame.FlatStyle = FlatStyle.Flat;
            btnNewGame.Font = new Font("Lucida Calligraphy", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnNewGame.ForeColor = Color.Black;
            btnNewGame.Location = new Point(361, 227);
            btnNewGame.Margin = new Padding(3, 2, 3, 2);
            btnNewGame.Name = "btnStartGame";
            btnNewGame.Size = new Size(180, 38);
            btnNewGame.TabIndex = 0;
            btnNewGame.Text = "New Game";
            btnNewGame.UseVisualStyleBackColor = false;
            btnNewGame.Click += btnNewGame_Click;
            // 
            // btnQuit
            // 
            btnQuit.BackColor = Color.Transparent;
            btnQuit.FlatAppearance.BorderSize = 0;
            btnQuit.FlatAppearance.MouseDownBackColor = Color.Transparent;
            btnQuit.FlatAppearance.MouseOverBackColor = Color.Transparent;
            btnQuit.FlatStyle = FlatStyle.Flat;
            btnQuit.Font = new Font("Lucida Calligraphy", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnQuit.ForeColor = Color.Black;
            btnQuit.Location = new Point(361, 280);
            btnQuit.Margin = new Padding(3, 2, 3, 2);
            btnQuit.Name = "btnQuit";
            btnQuit.Size = new Size(180, 38);
            btnQuit.TabIndex = 1;
            btnQuit.Text = "Quit";
            btnQuit.UseVisualStyleBackColor = false;
            btnQuit.Click += btnQuit_Click;
            // 
            // btnEasy
            // 
            btnEasy.BackColor = Color.Transparent;
            btnEasy.FlatAppearance.BorderSize = 0;
            btnEasy.FlatAppearance.MouseDownBackColor = Color.Transparent;
            btnEasy.FlatAppearance.MouseOverBackColor = Color.Transparent;
            btnEasy.FlatStyle = FlatStyle.Flat;
            btnEasy.Font = new Font("Lucida Calligraphy", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnEasy.ForeColor = Color.Black;
            btnEasy.Location = new Point(361, 227);
            btnEasy.Margin = new Padding(3, 2, 3, 2);
            btnEasy.Name = "btnEasy";
            btnEasy.Size = new Size(180, 38);
            btnEasy.TabIndex = 2;
            btnEasy.Text = "Easy";
            btnEasy.UseVisualStyleBackColor = false;
            btnEasy.Visible = false;
            btnEasy.Click += btnEasy_Click;
            // 
            // btnHard
            // 
            btnHard.BackColor = Color.Transparent;
            btnHard.FlatAppearance.BorderSize = 0;
            btnHard.FlatAppearance.MouseDownBackColor = Color.Transparent;
            btnHard.FlatAppearance.MouseOverBackColor = Color.Transparent;
            btnHard.FlatStyle = FlatStyle.Flat;
            btnHard.Font = new Font("Lucida Calligraphy", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnHard.ForeColor = Color.Black;
            btnHard.Location = new Point(361, 280);
            btnHard.Margin = new Padding(3, 2, 3, 2);
            btnHard.Name = "btnHard";
            btnHard.Size = new Size(180, 38);
            btnHard.TabIndex = 3;
            btnHard.Text = "Hard";
            btnHard.UseVisualStyleBackColor = false;
            btnHard.Visible = false;
            btnHard.Click += btnHard_Click;
            // 
            // GameOverForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(986, 432);
            Controls.Add(btnQuit);
            Controls.Add(btnHard);
            Controls.Add(btnEasy);
            Controls.Add(label1);
            Controls.Add(lblScore);
            Controls.Add(pictureBox1);
            Controls.Add(btnNewGame);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Margin = new Padding(3, 2, 3, 2);
            Name = "GameOverForm";
            Text = "Game Over";
            FormClosing += GameOverForm_FormClosing;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }
    }
}
