﻿using System;
using System.Windows.Forms;

namespace SnakeGame
{
    public partial class GameOverForm : Form
    {
        private int score;

        public GameOverForm(int score)
        {
            InitializeComponent();
            this.score = score;
            lblScore.Text = $"Your Score Was: {score}";
        }

        private void btnNewGame_Click(object sender, EventArgs e)
        {
            btnNewGame.Hide();
            btnEasy.Show();
            btnHard.Show();
            btnQuit.Location = new System.Drawing.Point(361, 333);
        }

        private void btnEasy_Click(object sender, EventArgs e)
        {
            EasyForm gameForm = new EasyForm();
            gameForm.Show();
            this.Hide();
        }

        private void btnHard_Click(object sender, EventArgs e)
        {
            Form1 gameForm = new Form1();
            gameForm.Show();
            this.Hide();
        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void GameOverForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
