﻿namespace SnakeGame
{
    partial class StartForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Button btnStartGame;
        private System.Windows.Forms.Button btnQuit;
        private System.Windows.Forms.Button btnEasy;
        private System.Windows.Forms.Button btnHard;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(StartForm));
            btnStartGame = new Button();
            btnQuit = new Button();
            btnEasy = new Button();
            btnHard = new Button();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // btnStartGame
            // 
            btnStartGame.BackColor = Color.Transparent;
            btnStartGame.FlatAppearance.BorderSize = 0;
            btnStartGame.FlatAppearance.MouseDownBackColor = Color.Transparent;
            btnStartGame.FlatAppearance.MouseOverBackColor = Color.Transparent;
            btnStartGame.FlatStyle = FlatStyle.Flat;
            btnStartGame.Font = new Font("Lucida Calligraphy", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnStartGame.ForeColor = Color.Black;
            btnStartGame.Location = new Point(361, 227);
            btnStartGame.Margin = new Padding(3, 2, 3, 2);
            btnStartGame.Name = "btnStartGame";
            btnStartGame.Size = new Size(180, 38);
            btnStartGame.TabIndex = 0;
            btnStartGame.Text = "Start Game";
            btnStartGame.UseVisualStyleBackColor = false;
            btnStartGame.Click += btnStartGame_Click;
            // 
            // btnQuit
            // 
            btnQuit.BackColor = Color.Transparent;
            btnQuit.FlatAppearance.BorderSize = 0;
            btnQuit.FlatAppearance.MouseDownBackColor = Color.Transparent;
            btnQuit.FlatAppearance.MouseOverBackColor = Color.Transparent;
            btnQuit.FlatStyle = FlatStyle.Flat;
            btnQuit.Font = new Font("Lucida Calligraphy", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnQuit.ForeColor = Color.Black;
            btnQuit.Location = new Point(361, 280);
            btnQuit.Margin = new Padding(3, 2, 3, 2);
            btnQuit.Name = "btnQuit";
            btnQuit.Size = new Size(180, 38);
            btnQuit.TabIndex = 1;
            btnQuit.Text = "Quit";
            btnQuit.UseVisualStyleBackColor = false;
            btnQuit.Click += btnQuit_Click;
            // 
            // btnEasy
            // 
            btnEasy.BackColor = Color.Transparent;
            btnEasy.FlatAppearance.BorderSize = 0;
            btnEasy.FlatAppearance.MouseDownBackColor = Color.Transparent;
            btnEasy.FlatAppearance.MouseOverBackColor = Color.Transparent;
            btnEasy.FlatStyle = FlatStyle.Flat;
            btnEasy.Font = new Font("Lucida Calligraphy", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnEasy.ForeColor = Color.Black;
            btnEasy.Location = new Point(361, 227);
            btnEasy.Margin = new Padding(3, 2, 3, 2);
            btnEasy.Name = "btnEasy";
            btnEasy.Size = new Size(180, 38);
            btnEasy.TabIndex = 2;
            btnEasy.Text = "Easy";
            btnEasy.UseVisualStyleBackColor = false;
            btnEasy.Visible = false;
            btnEasy.Click += btnEasy_Click;
            // 
            // btnHard
            // 
            btnHard.BackColor = Color.Transparent;
            btnHard.FlatAppearance.BorderSize = 0;
            btnHard.FlatAppearance.MouseDownBackColor = Color.Transparent;
            btnHard.FlatAppearance.MouseOverBackColor = Color.Transparent;
            btnHard.FlatStyle = FlatStyle.Flat;
            btnHard.Font = new Font("Lucida Calligraphy", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnHard.ForeColor = Color.Black;
            btnHard.Location = new Point(361, 280);
            btnHard.Margin = new Padding(3, 2, 3, 2);
            btnHard.Name = "btnHard";
            btnHard.Size = new Size(180, 38);
            btnHard.TabIndex = 3;
            btnHard.Text = "Hard";
            btnHard.UseVisualStyleBackColor = false;
            btnHard.Visible = false;
            btnHard.Click += btnHard_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Lucida Calligraphy", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(258, 39);
            label1.Name = "label1";
            label1.Size = new Size(452, 36);
            label1.TabIndex = 4;
            label1.Text = "Welcome to SnakeGame V1.0";
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Transparent;
            pictureBox1.BackgroundImageLayout = ImageLayout.Zoom;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(599, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(384, 350);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 5;
            pictureBox1.TabStop = false;
            // 
            // StartForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(986, 432);
            Controls.Add(btnStartGame);
            Controls.Add(btnQuit);
            Controls.Add(btnEasy);
            Controls.Add(btnHard);
            Controls.Add(label1);
            Controls.Add(pictureBox1);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Margin = new Padding(3, 2, 3, 2);
            Name = "StartForm";
            Text = "Snake Game";
            FormClosing += StartForm_FormClosing;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        private Label label1;
        private PictureBox pictureBox1;
    }
}
