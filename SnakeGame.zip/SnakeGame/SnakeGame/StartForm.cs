﻿using System;
using System.Windows.Forms;

namespace SnakeGame
{
    public partial class StartForm : Form
    {
        public StartForm()
        {
            InitializeComponent();
        }

        private void btnStartGame_Click(object sender, EventArgs e)
        {
            btnStartGame.Hide();
            btnEasy.Show();
            btnHard.Show();
            btnQuit.Location = new System.Drawing.Point(361, 333);
        }

        private void btnEasy_Click(object sender, EventArgs e)
        {
            EasyForm gameForm = new EasyForm();
            gameForm.Show();
            this.Hide();
        }

        private void btnHard_Click(object sender, EventArgs e)
        {
            Form1 gameForm = new Form1();
            gameForm.Show();
            this.Hide();
        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void StartForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
